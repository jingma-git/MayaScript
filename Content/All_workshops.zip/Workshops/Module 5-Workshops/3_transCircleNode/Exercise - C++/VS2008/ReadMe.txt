========================================================================
    MayaPluginWizard : "transCircleNode" Project Overview
========================================================================

MayaPluginWizard has created this "transCircleNode" project for you as a starting point.

This file contains a summary of what you will find in each of the files that make up your project.

MayaPluginWizard.vcproj
    This is the main project file for projects generated using an Application Wizard. 
    It contains information about the version of the product that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

Options.txt
	This text file explains which options you selected for your new project.

/////////////////////////////////////////////////////////////////////////////
Other notes:

For this exercise, search for the TODO keywords and follow the instructions in
comments. If you are unsure of what you need to do, feel free to ask the instructor
or look into the solution folder.
Each //... line is a line of code you need to write or complete.

/////////////////////////////////////////////////////////////////////////////
